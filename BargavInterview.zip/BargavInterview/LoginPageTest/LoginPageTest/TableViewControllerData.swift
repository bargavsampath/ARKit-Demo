//
//  TableViewControllerData.swift
//  LoginPageTest
//
//  Created by Falin on 28/9/20.
//  Copyright © 2020 Poket. All rights reserved.
//

import UIKit

class TableViewControllerData: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var testData = [TestData]()
    let urlString = "https://brandsuat.poket.com/testapi3.php"
    let cellId = "MyCell"
    let nib = "CustomTableViewCell"
    var imageNames = [String]()
    
    @IBOutlet weak var tableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imageNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:cellId, for: indexPath) as! CustomTableViewCell
        cell.myImage.image = UIImage(named: imageNames[indexPath.row])
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName:nib, bundle: nil), forCellReuseIdentifier:cellId)
        getData(urlString: urlString)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func getData(urlString:String) {
        guard let dataUrl = URL(string: urlString) else {return}
        let request = URLRequest(url: dataUrl)
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) -> Void in
            if let error = error {
                print(error)
                return
            }
            // Parse JSON data
            if let data = data {
                self.testData = self.parseJsonData(data: data)
                // Reload table view
                OperationQueue.main.addOperation({
                        self.imageNames = ["dhoni","sachin","ganguly","yuvraj","kohli","rohit","raina","jadeja","samson"]
                    self.tableView.reloadData()
                })
            }
        })
        task.resume()
    }
    
    func parseJsonData(data: Data) -> [TestData] {
        var testData = [TestData]()
        do {
            let jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
            // Parse JSON data
            var data = TestData()
            data.message = jsonResult?["message"] as! String
            data.status = jsonResult?["status"] as! Bool
            testData.append(data)
        } catch {
            print(error)
        }
        return testData
    }
}




