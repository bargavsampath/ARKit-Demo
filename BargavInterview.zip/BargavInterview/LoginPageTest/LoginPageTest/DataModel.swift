//
//  DataModel.swift
//  LoginPageTest
//
//  Created by Falin on 28/9/20.
//  Copyright © 2020 Poket. All rights reserved.
//

import Foundation

struct TestData {
    var message = ""
    var status = false
}
