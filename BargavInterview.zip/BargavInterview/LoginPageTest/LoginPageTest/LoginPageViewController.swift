//
//  ViewController.swift
//  LoginPageTest
//
//  Created by Falin on 28/9/20.
//  Copyright © 2020 Poket. All rights reserved.
//

import UIKit

class LoginPageViewController: UIViewController {

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loginButtonPressed(_ sender: UIButton) {
        let errorMsg = "Invalid Credentials"
        let (validEmailid,validPswd) = ("test1@pocket.com","1234")
        guard let emailid = emailTextField.text else{
            return
        }
        guard !emailid.isEmpty, emailid == validEmailid  else{
            showAlert(message1:"Enter valid email Id",message2:errorMsg)
            return
        }
        guard let pswd = passwordTextField.text else{return}
        guard !pswd.isEmpty, pswd == validPswd else{
            showAlert(message1: "Enter valid password", message2:errorMsg)
            return
        }
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "NewViewController") as! TableViewControllerData
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    
    func showAlert(message1:String,message2:String){
        let alert = UIAlertController(title:message2, message: message1, preferredStyle: .alert)
        let action = UIAlertAction(title: "Dismiss", style:.cancel)
        alert.addAction(action)
        present(alert,animated: true)
    }
 }
